//
//  CustomCell.swift
//  todoList
//
//  Created by Seyma Akin on 1/23/18.
//  Copyright © 2018 Seyma Akin. All rights reserved.
//

import UIKit

class CustomCelll: UITableViewCell {
    @IBOutlet weak var TitleLabel: UILabel!
    @IBOutlet weak var DetailLabel: UILabel!
    @IBOutlet weak var DateLabel: UILabel!
}
